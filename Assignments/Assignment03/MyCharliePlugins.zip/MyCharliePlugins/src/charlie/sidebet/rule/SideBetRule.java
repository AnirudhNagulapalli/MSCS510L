/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package charlie.sidebet.rule;

import charlie.card.Card;
import charlie.card.Hand;
import charlie.plugin.ISideBetRule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Anirudh
 */
public class SideBetRule implements ISideBetRule{
    private final Logger LOG = LoggerFactory.getLogger(SideBetRule.class);

    private final Double PAYOFF_SUPER7 = 3.0;
    private final Double PAYOFF_ROYALMATCH = 25.0;
    private final Double PAYOFF_EXACT13 = 1.0;

    /**
     * Apply rule to the hand and return the payout if the rule matches
     * and the negative bet if the rule does not match.
     * @param hand Hand to analyze.
     * @return
     */
    @Override
    public double apply(Hand hand) {


        Double bet = hand.getHid().getSideAmt();
        LOG.info("side bet amount = "+bet);

        if(bet == 0)
            return 0.0;

        LOG.info("side bet rule applying hand = "+hand);
        
        double PAYOFF = 0;
        double EXACT13_PAYOFF;
        Card card1 = hand.getCard(0);
        Card card2 = hand.getCard(1);
        
        // Super7 Scenario
        if(card1.getRank() == 7) {
            LOG.info("side bet SUPER 7 matches");
            PAYOFF = bet * PAYOFF_SUPER7;
        }

        // Royal Match Scenario
        if(card1.getSuit() == card2.getSuit()){
            if((card1.getName().equals("K")) && (card2.getName().equals("Q")) || 
                    (card1.getName().equals("Q")) && (card2.getName().equals("K"))){
                LOG.info("side bet ROYAL MATCH matches");
                PAYOFF = bet * PAYOFF_ROYALMATCH;
            }
        }
            
        // Exact 13 Scenario
        if(card1.getRank() + card2.getRank() == 13){
            LOG.info("side bet EXACT 13 matches");
            EXACT13_PAYOFF = bet * PAYOFF_EXACT13;
            
            if(EXACT13_PAYOFF > PAYOFF){
                PAYOFF = EXACT13_PAYOFF;
            }
        }
        
        //Checks for win/lose condition
        if(PAYOFF > 0){
            return PAYOFF;
        }
        else{
            LOG.info("side bet rule no match");
            return -bet;
        }
    }

}
