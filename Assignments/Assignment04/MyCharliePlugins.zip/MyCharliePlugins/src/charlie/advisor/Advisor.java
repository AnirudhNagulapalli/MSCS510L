/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package charlie.advisor;
import charlie.card.Card;
import charlie.card.Hand;
import charlie.plugin.IAdvisor;
import charlie.util.Play;
import java.util.HashMap;
/**
 *
 * @author Anirudh
 */
public class Advisor extends BasicStrategy implements IAdvisor {
    

    Play[] result;
    @Override
    public Play advise(Hand myHand, Card upCard) {
        Card myCard1 = myHand.getCard(0);               //1st Card
        Card myCard2 = myHand.getCard(1);               //2nd Card
        int MyTotal = myHand.getValue();                //Count (Card1+Card2)
        String DealerCard;                              //Dealers Open Card
        String Card1Value;
        String Card2Value;
            
        if((myHand.getValue()>0) && (myHand.getValue()<21) && upCard!=null){
            
            if(myCard1.isAce())
                Card1Value = "A";
            else
                Card1Value = Integer.toString(myCard1.value());
            
            if(myCard2.isAce())
                Card2Value = "A";
            else
                Card2Value = Integer.toString(myCard2.value());
            
            if (upCard.isAce()){
                DealerCard = "A";
            }
            else {
                DealerCard = Integer.toString(upCard.value());
            }

            if(Card1Value!=Card2Value){                     //If Cards are not same
                if(MyTotal>=12 && MyTotal<=20){             //If 11<Count<21
                    String PlayerValue = Integer.toString(myHand.getValue());
                    //Give Inputs to GreaterThan11 HashMap
                    result = GreaterThan11.get(PlayerValue);
                }

                else if(MyTotal>=5 && MyTotal<=11){         //If 4<Count<12
                    String PlayerValue = Integer.toString(myHand.getValue());
                    //Give Inputs to LessThanOrEqual11 HashMap
                    result = LessThanOrEqual11.get(PlayerValue);
                }
            }        
            if(Card1Value.equals("A") && !Card2Value.equals("A")){        //If 1st Card is an Ace
                //Give Inputs as A, 2nd Card to SingleAce HashMap
                result = SingleAce.get("A,"+Card2Value);
            }
            else if(Card2Value.equals("A") && !Card1Value.equals("A")){   //If 2nd Card is an Ace
                //Give Inputs as A, 1st Card to SingleAce HashMap
                result = SingleAce.get("A,"+Card1Value);
            }
            if(Card1Value.equals(Card2Value)){                    //If Cards are same
                //Return both Cards to Equals HashMap
                result = Equals.get(Card1Value+","+Card2Value);
            }

            if(DealerCard.equals("A")) {                       //If Dealers Card is an Ace
                //Returns Value for result[9] in result array
                return result[9];
            }
            else{
                return result[upCard.value()-2];      //As array index starts from 0
            }
        }
        else {
            return Play.STAY;
        }
    }
    
}
