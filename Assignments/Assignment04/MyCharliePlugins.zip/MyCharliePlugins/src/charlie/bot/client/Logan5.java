/**
 * file: Logan5.java author: Anirudh Nagulapalli course: Software
 * Design and Development assignment: Assignment 4 - Logan5 
 * due date: May 12, 2017
 *
 * This file contains the implementation of Logan
 */
package charlie.bot.client;

import charlie.actor.Courier;
import charlie.advisor.Advisor;
import charlie.card.Card;
import charlie.card.Hand;
import charlie.card.Hid;
import charlie.dealer.Seat;
import charlie.plugin.ILogan5;
import charlie.util.Play;
import charlie.view.AMoneyManager;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.text.DecimalFormat;
//import java.util.Date;
import java.util.List;
import java.util.Random;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Anirudh
 */
public class Logan5 implements ILogan5 {
    
    protected final Logger LOG = LoggerFactory.getLogger(Logan5.class);
    protected final int THINK_TIME = 5;
    private Courier courier;
    protected Hand dealerHand, myHand;
    protected Hid dealerHid, myHid;
    private AMoneyManager moneyManager;
    protected Seat mine;
    protected Random ran = new Random();
    protected boolean myTurn = false;
    protected int count = 0;
    protected int trueCount, betAmount, totalBet, meanBet, countDecks;
    protected double numOfDecks;
    protected static final int Minimum_Bet = 5;
    boolean firstTime = true;
    protected int maxBet = Minimum_Bet;
    protected int numOfBJ = 0;
    protected int numOfCharlie = 0;
    protected int numOfWin = 0;
    protected int numOfBreak = 0;
    protected int numOfLose = 0;
    protected int numOfPush = 0;
    protected int gamesPlayed = 0;
    protected double startTime;
    protected double currentTime;
    protected double minutesPlayed;
    public final static int X = 10;
    public final static int Y = 250;
    protected Font displayFont = new Font("Calibri", Font.ITALIC, 16);
    Advisor PlayRule = new Advisor();

    /**
     * Places a bet after hitting the go button
     * 
     */
    @Override
    public void go() {
        currentTime = System.currentTimeMillis();
        if (firstTime) {
            startTime = System.currentTimeMillis();
            betAmount = Minimum_Bet;
            moneyManager.upBet(betAmount);
            firstTime = false;
        } else {
            trueCount = count / countDecks;
            betAmount = Math.max(Minimum_Bet, Minimum_Bet * trueCount + Minimum_Bet);
            if (betAmount > maxBet) {
                maxBet = betAmount;
            }
            moneyManager.clearBet();
            int numOf100s = betAmount / 100;
            int numOf25s = (betAmount % 100) / 25;
            int numOf5s = (betAmount % 100 % 25) / 5;
            //place 100 chips
            for (int i = 0; i < numOf100s; i++) {
                moneyManager.upBet(100);
            }
            //place 25 chips
            for (int i = 0; i < numOf25s; i++) {
                moneyManager.upBet(25);
            }
            //place 5 chips
            for (int i = 0; i < numOf5s; i++) {
                moneyManager.upBet(5);
            }
        }
        totalBet += betAmount;
        courier.bet(betAmount, 0);
    }
    
    @Override
    public void setCourier(Courier courier) {
        this.courier = courier;
    }
    
    /**
     * Sets the money manager for managing bets.
     *
     * @param moneyManager Money manager
     */
    @Override
    public void setMoneyManager(AMoneyManager moneyManager) {
        this.moneyManager = moneyManager;
    }
    
    /**
     * Updates the bot.
     */
    @Override
    public void update() {
        //this.end = new Date();
    
    }
    
    /**
     * Renders the bot.
     *
     * @param g Graphics context.
     */
    @Override
    public void render(Graphics2D g) {
        // Calculating the time played by games.
        minutesPlayed = (currentTime - startTime) / 60000;
        DecimalFormat timeFormat = new DecimalFormat("##");
        DecimalFormat shoeFormat = new DecimalFormat("##.##");
        g.setFont(displayFont);
        g.setColor(Color.YELLOW);
        g.drawString("Counting Strategy: Hi-Lo", X, Y - 45);
        g.drawString("True count:  " + trueCount, X, Y - 30);
        g.drawString("Shoe size:  " + shoeFormat.format(numOfDecks), X, Y -15);
        g.drawString("Running count:  " + count, X, Y);
        g.drawString("Max bet amount:  " + maxBet, X, Y + 15);
        g.drawString("Mean bet amount per game:  " + meanBet, X, Y + 30);
        g.drawString("Number of Minutes played: " + timeFormat.format(minutesPlayed), X, Y + 45);
        g.drawString("Number of Games played: " + gamesPlayed, X, Y + 60);
        g.drawString("BlackJack: " + numOfBJ, X, Y - 195);
        g.drawString("Charlie: " + numOfCharlie, X, Y - 180);
        g.drawString("Wins: " + numOfWin, X, Y - 165);
        g.drawString("Breaks: " + numOfBreak, X, Y - 150);
        g.drawString("Loses: " + numOfLose, X, Y - 135);
        g.drawString("Pushes: " + numOfPush, X, Y - 120);
    }

    /**
     * Starts a game
     * 
     */
    @Override
    public void startGame(List<Hid> hids, int shoeSize) {
        myTurn = false;
        for (Hid h : hids) {
            if (h.getSeat() == Seat.DEALER) {
                this.dealerHand = new Hand(new Hid(Seat.DEALER));
                dealerHand = new Hand(h);
                dealerHid = dealerHand.getHid();
                continue;
            }
            if (h.getSeat() == Seat.YOU) {
                myHand = new Hand(h);
                mine = h.getSeat();
                myHid = new Hid(mine);
            }
        }
    }

    /**
     * Ends a game
     * 
     */
    @Override
    public void endGame(int shoeSize) {
        numOfDecks = shoeSize / 52.0;
        countDecks = (int) Math.round(numOfDecks);
        if (countDecks < 1) {
            countDecks = 1;
        }
        gamesPlayed += 1;
        meanBet = (int) Math.round((double) totalBet / gamesPlayed);
        myTurn = false;
    }
    
     /**
     * Deals a card
     *
     */
    @Override
    public void deal(Hid hid, Card card, int[] values) {
        if (card == null) {
            return;
        }
        if (hid.getSeat() == Seat.DEALER) {
            dealerHand.hit(card);
        }
        if (hid.getSeat() == Seat.YOU) {
            myHand.hit(card);
            if (myTurn) {
                gamePlay(hid);
            }
        }
        // count +1 if card is between 2 and 7
        if (card.getRank() >= 2 && card.getRank() < 7) {
            count += 1;
        }
        // count -1 if card is ace or above 10
        if (card.isFace() || card.isAce() || card.getRank() == 10) {
            count -= 1;
        }
    }

    @Override
    public void insure() {
        
    }

    /**
     * Counts busts
     *
     */
    @Override
    public void bust(Hid hid) {
        numOfBreak += 1;
        myTurn = false;

    }

    /**
     * Counts wins
     *
     */
    @Override
    public void win(Hid hid) {
        numOfWin += 1;
        myTurn = false;
    }

    /**
     * Counts blackjacks
     *
     */
    @Override
    public void blackjack(Hid hid) {
        numOfBJ += 1;
        myTurn = false;
    }

    /**
     * Counts charlies
     *
     */
    @Override
    public void charlie(Hid hid) {
        numOfCharlie += 1;
        myTurn = false;
    }
    
    /**
     * Counts loses
     *
     */
    @Override
    public void lose(Hid hid) {
        numOfLose += 1;
        myTurn = false;
    }

    /**
     * Counts pushes
     *
     */
    @Override
    public void push(Hid hid) {
        numOfPush += 1;
        myTurn = false;
    }

    /**
     * Shuffles
     *
     */
    @Override
    public void shuffling() {
        count = 0;
    }

    @Override
    public void play(Hid hid) {
        if (hid.getSeat() != mine) {
            myTurn = false;
            return;
        }
        myTurn = true;
        gamePlay(hid);
    }
    
    public Play correctPlay(Play play) {
        if (play == Play.HIT || play == Play.STAY) {
            return play;
        }
        if (play == Play.DOUBLE_DOWN) {
            if (myHand.size() == 2) {
                myHand.dubble();
                return Play.DOUBLE_DOWN;
            }
            return Play.HIT;
        }
        // incase of split if handvalue > 18 stays else hits
        if (myHand.getValue() >= 18) {
            return Play.STAY;
        }
        return Play.HIT;
    }

    public void gamePlay(Hid hid) {
        Card upCard = dealerHand.getCard(0);
        Play play = correctPlay(PlayRule.advise(myHand, upCard));
        int thinking = ran.nextInt(THINK_TIME) * 500;
        try {
            Thread.sleep(thinking);   
        } catch (InterruptedException e) {
            LOG.error(e + "occured");
        }
        //paly hit
        if (play == Play.HIT) {
            courier.hit(hid);
        }
        //play Double Down
        if (play == Play.DOUBLE_DOWN) {
            courier.dubble(hid);
            myTurn = false;
        }
        //play Stay
        if (play == Play.STAY) {
            courier.stay(hid);
            myTurn = false;
        }
    }
}
